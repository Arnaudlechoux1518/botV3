
import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { SimulationProvider } from '@/context/SimulationContext';
import Layout from '@/components/Layout';
import WalletManager from '@/components/WalletManager';
import SimulationConfig from '@/components/SimulationConfig';
import TransactionMonitor from '@/components/TransactionMonitor';
import SubscriptionPlans from '@/components/SubscriptionPlans';
import Analytics from '@/components/Analytics';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { PlayIcon, StopCircleIcon, ArrowLeftIcon, LogOutIcon, ArrowDownIcon, ArrowUpIcon } from 'lucide-react';
import { useSimulation } from '@/context/SimulationContext';
import { useAuth } from '@/context/AuthContext';
import { toast } from '@/components/ui/use-toast';

// Bulk Trade Buttons Component
const BulkTradeButtons = () => {
  const { wallets, isRunning } = useSimulation();
  
  const handleBuyAll = () => {
    if (wallets.length < 2) {
      toast({
        title: "Not Enough Wallets",
        description: "You need at least 2 wallets to execute bulk buys.",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "Bulk Buy Initiated",
      description: `Started buy transactions across ${wallets.length} wallets.`,
    });
  };

  const handleSellAll = () => {
    if (wallets.length < 2) {
      toast({
        title: "Not Enough Wallets",
        description: "You need at least 2 wallets to execute bulk sells.",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "Bulk Sell Initiated",
      description: `Started sell transactions across ${wallets.length} wallets.`,
    });
  };

  return (
    <div className="flex flex-col md:flex-row gap-3 mb-6">
      <Button
        className="bg-green-600 hover:bg-green-700 text-white w-full justify-center"
        disabled={isRunning || wallets.length < 2}
        onClick={handleBuyAll}
      >
        <ArrowDownIcon size={16} className="mr-2" />
        Buy With All Wallets
      </Button>
      <Button 
        className="bg-red-600 hover:bg-red-700 text-white w-full justify-center"
        disabled={isRunning || wallets.length < 2}
        onClick={handleSellAll}
      >
        <ArrowUpIcon size={16} className="mr-2" />
        Sell With All Wallets
      </Button>
    </div>
  );
};

// Control Panel Component
const ControlPanel = () => {
  const { startSimulation, stopSimulation, isRunning, selectedPlan } = useSimulation();
  const { isAuthenticated } = useAuth();

  return (
    <div className="fixed bottom-8 left-1/2 transform -translate-x-1/2 z-50 animate-slide-up">
      <div className="glass-card p-3 rounded-full flex items-center space-x-4 shadow-glass-lg">
        {!isRunning ? (
          <Button 
            onClick={startSimulation} 
            disabled={!isAuthenticated || !selectedPlan}
            className="bg-solana hover:bg-solana/90 text-white rounded-full px-6"
          >
            <PlayIcon size={18} className="mr-2" />
            Launch Volume Bot
          </Button>
        ) : (
          <Button 
            variant="destructive" 
            onClick={stopSimulation}
            className="rounded-full px-6"
          >
            <StopCircleIcon size={18} className="mr-2" />
            Stop Transactions
          </Button>
        )}
        
        {!isAuthenticated && (
          <p className="text-sm text-muted-foreground animate-pulse">
            <Link to="/auth" className="text-solana hover:underline">Log in</Link> to start using the volume bot
          </p>
        )}
        {isAuthenticated && !selectedPlan && !isRunning && (
          <p className="text-sm text-muted-foreground animate-pulse">
            Select a subscription plan to start
          </p>
        )}
      </div>
    </div>
  );
};

// User Profile Component
const UserProfile = () => {
  const { user, logout } = useAuth();
  
  if (!user) return null;
  
  return (
    <div className="bg-white dark:bg-pump-light/10 p-6 rounded-xl border border-gray-200 dark:border-pump-light/20 mb-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-semibold">Welcome, {user.email}</h3>
          {user.subscription && (
            <p className="text-sm text-muted-foreground">
              <span className="inline-flex items-center text-emerald-500 gap-1">
                <span className="h-2 w-2 rounded-full bg-emerald-500"></span>
                Active Subscription
              </span>
              {' • '}
              {user.subscription.plan.toUpperCase()} Plan
              {' • '}
              Expires: {new Date(user.subscription.expiresAt).toLocaleDateString()}
            </p>
          )}
        </div>
        <Button variant="outline" size="sm" onClick={logout}>
          <LogOutIcon size={16} className="mr-2" />
          Log Out
        </Button>
      </div>
    </div>
  );
};

// Dashboard Page
const Dashboard = () => {
  const { isAuthenticated, isLoading } = useAuth();
  const navigate = useNavigate();
  
  // Redirect to auth page if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      // Note: Not forcing redirect to allow viewing of the dashboard UI
      // navigate('/auth');
    }
  }, [isAuthenticated, isLoading, navigate]);

  return (
    <SimulationProvider>
      <Layout>
        <div className="flex items-center mb-6">
          <Link to="/" className="flex items-center text-sm text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeftIcon size={16} className="mr-1" />
            Back to Home
          </Link>
        </div>

        <div className="space-y-6 pb-20">
          <div className="space-y-2 text-center max-w-3xl mx-auto mb-8">
            <h1 className="text-3xl font-bold tracking-tight">
              Pump.fun Volume Bot
            </h1>
            <p className="text-muted-foreground">
              Generate trading volume for your Pump.fun tokens with multiple wallets
            </p>
          </div>

          {isAuthenticated && <UserProfile />}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <WalletManager />
            <SimulationConfig />
          </div>

          <BulkTradeButtons />

          <SubscriptionPlans />
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="h-full">
              <TransactionMonitor />
            </div>
            <div>
              <Analytics />
            </div>
          </div>
        </div>
        
        <ControlPanel />
      </Layout>
    </SimulationProvider>
  );
};

export default Dashboard;
