import React from 'react';
import Layout from '@/components/Layout';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { CheckIcon, ArrowRightIcon, RocketIcon } from 'lucide-react';
import { subscriptionPlans } from '@/lib/mockData';

const Index = () => {
  return (
    <Layout>
      {/* Hero Section */}
      <div className="py-16 md:py-24 text-center">
        <div className="max-w-3xl mx-auto space-y-6">
          <div className="flex justify-center mb-6">
            <div className="bg-solana/10 dark:bg-solana/20 p-4 rounded-full">
              <RocketIcon 
                size={60}
                className="text-solana"
              />
            </div>
          </div>
          
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight">
            Pump.fun Trading Volume Bot
          </h1>
          
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
            Boost your Pump.fun token's trading volume with our advanced volume bot tool. Generate realistic trading activity across multiple wallets.
          </p>
          
          <div className="pt-4">
            <Link to="/dashboard">
              <Button size="lg" className="bg-solana hover:bg-solana/90 text-white rounded-full px-8">
                Launch Volume Bot
                <ArrowRightIcon size={18} className="ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-16 bg-gray-50 dark:bg-pump-light/5 rounded-xl">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold">Key Features</h2>
            <p className="text-muted-foreground mt-2">Everything you need to boost your token's visibility</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 px-4">
            <FeatureCard 
              title="Multi-Wallet Trading"
              description="Generate transactions across up to 25 wallets, optimizing liquidity and enhancing market dynamics with natural trading patterns."
              icon={
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <rect width="20" height="14" x="2" y="5" rx="2" />
                  <line x1="2" x2="22" y1="10" y2="10" />
                </svg>
              }
            />
            
            <FeatureCard 
              title="Customizable Parameters"
              description="Define min/max amounts, transaction delays, and other parameters to suit your strategy."
              icon={
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" />
                  <circle cx="12" cy="12" r="3" />
                </svg>
              }
            />
            
            <FeatureCard 
              title="Real-time Monitoring"
              description="Track transactions, total volume, and other metrics in real-time with detailed analytics."
              icon={
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M3 3v18h18" />
                  <path d="m19 9-5 5-4-4-3 3" />
                </svg>
              }
            />
          </div>
        </div>
      </div>

      {/* Pricing Section */}
      <div className="py-16">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold">Subscription Plans</h2>
            <p className="text-muted-foreground mt-2">Choose the plan that fits your needs</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 px-4">
            {subscriptionPlans.map((plan) => (
              <div
                key={plan.id}
                className="relative p-6 rounded-xl border border-gray-200 dark:border-pump-light/20 bg-white dark:bg-pump-light/5 transition-all hover:shadow-md overflow-hidden"
              >
                {plan.id === '1y' && (
                  <div className="absolute -right-12 top-5 bg-solana-secondary text-white text-xs py-1 px-10 transform rotate-45">
                    Best Value
                  </div>
                )}
                
                <div className="text-center mb-4">
                  <h3 className="font-bold text-xl">{plan.name}</h3>
                  <p className="text-sm text-muted-foreground">{plan.duration}</p>
                </div>
                
                <div className="text-center my-6">
                  <span className="text-4xl font-bold">{plan.price}</span>
                  <span className="text-lg ml-1">SOL</span>
                </div>
                
                <ul className="space-y-3 mt-6 mb-8">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-start text-sm">
                      <CheckIcon size={18} className="mr-2 text-solana shrink-0 mt-0.5" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <div className="mt-auto text-center">
                  <Link to={`/auth?plan=${plan.id}`}>
                    <Button variant="outline" className="w-full">
                      Select Plan
                    </Button>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="py-12 mb-8 bg-solana/10 dark:bg-solana/20 rounded-xl text-center">
        <div className="max-w-3xl mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-bold mb-4">Ready to boost your token's trading volume?</h2>
          <p className="text-muted-foreground mb-6">Get started today and watch your token's visibility grow</p>
          <Link to="/dashboard">
            <Button size="lg" className="bg-solana hover:bg-solana/90 text-white">
              Launch Volume Bot
              <ArrowRightIcon size={18} className="ml-2" />
            </Button>
          </Link>
        </div>
      </div>
    </Layout>
  );
};

// Feature Card Component
const FeatureCard = ({ title, description, icon }: { title: string; description: string; icon: React.ReactNode }) => {
  return (
    <div className="bg-white dark:bg-pump-light/10 p-6 rounded-xl border border-gray-200 dark:border-pump-light/20">
      <div className="w-12 h-12 bg-solana/10 dark:bg-solana/20 rounded-full flex items-center justify-center text-solana mb-4">
        {icon}
      </div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-muted-foreground">{description}</p>
    </div>
  );
};

export default Index;
