
import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import Layout from '@/components/Layout';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/context/AuthContext';
import { RocketIcon, KeyIcon, MailIcon, EyeIcon, EyeOffIcon } from 'lucide-react';
import { subscriptionPlans } from '@/lib/mockData';

const Auth = () => {
  const [activeTab, setActiveTab] = useState('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  
  const navigate = useNavigate();
  const location = useLocation();
  const { login, register, isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();
  
  // Parse plan from URL query params
  useEffect(() => {
    const queryParams = new URLSearchParams(location.search);
    const planParam = queryParams.get('plan');
    if (planParam) {
      setSelectedPlan(planParam);
      setActiveTab('register');
    }
  }, [location]);
  
  // Redirect if already authenticated
  useEffect(() => {
    if (isAuthenticated) {
      navigate('/dashboard');
    }
  }, [isAuthenticated, navigate]);
  
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      toast({
        title: "Missing Fields",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }
    
    await login(email, password);
  };
  
  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password || !confirmPassword || !selectedPlan) {
      toast({
        title: "Missing Fields",
        description: "Please fill in all required fields and select a subscription plan.",
        variant: "destructive",
      });
      return;
    }
    
    if (password !== confirmPassword) {
      toast({
        title: "Passwords Don't Match",
        description: "The passwords you entered don't match. Please try again.",
        variant: "destructive",
      });
      return;
    }
    
    await register(email, password, selectedPlan);
  };
  
  // Find selected plan details
  const planDetails = selectedPlan 
    ? subscriptionPlans.find(plan => plan.id === selectedPlan) 
    : null;
  
  return (
    <Layout>
      <div className="flex justify-center py-12">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4">
              <div className="bg-solana/10 p-4 rounded-full">
                <RocketIcon size={40} className="text-solana" />
              </div>
            </div>
            <CardTitle className="text-2xl">Welcome to Pump.fun Bot</CardTitle>
            <CardDescription>
              {activeTab === 'login' 
                ? 'Log in to access your trading bot'
                : 'Create an account to get started'}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-6">
                <TabsTrigger value="login">Login</TabsTrigger>
                <TabsTrigger value="register">Register</TabsTrigger>
              </TabsList>
              
              <TabsContent value="login">
                <form onSubmit={handleLogin} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <div className="relative">
                      <MailIcon className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input 
                        id="email" 
                        type="email" 
                        placeholder="your@email.com" 
                        className="pl-10"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="password">Password</Label>
                    <div className="relative">
                      <KeyIcon className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input 
                        id="password" 
                        type={showPassword ? "text" : "password"} 
                        placeholder="••••••••" 
                        className="pl-10"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                      />
                      <button 
                        type="button"
                        className="absolute right-3 top-3 text-muted-foreground hover:text-foreground"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? <EyeOffIcon size={16} /> : <EyeIcon size={16} />}
                      </button>
                    </div>
                  </div>
                  
                  <Button 
                    type="submit" 
                    className="w-full bg-solana hover:bg-solana/90 text-white"
                    disabled={isLoading}
                  >
                    {isLoading ? "Logging in..." : "Log In"}
                  </Button>
                </form>
              </TabsContent>
              
              <TabsContent value="register">
                <form onSubmit={handleRegister} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="register-email">Email</Label>
                    <div className="relative">
                      <MailIcon className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input 
                        id="register-email" 
                        type="email" 
                        placeholder="your@email.com" 
                        className="pl-10"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="register-password">Password</Label>
                    <div className="relative">
                      <KeyIcon className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input 
                        id="register-password" 
                        type={showPassword ? "text" : "password"} 
                        placeholder="••••••••" 
                        className="pl-10"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                      />
                      <button 
                        type="button"
                        className="absolute right-3 top-3 text-muted-foreground hover:text-foreground"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? <EyeOffIcon size={16} /> : <EyeIcon size={16} />}
                      </button>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="confirm-password">Confirm Password</Label>
                    <div className="relative">
                      <KeyIcon className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input 
                        id="confirm-password" 
                        type={showPassword ? "text" : "password"} 
                        placeholder="••••••••" 
                        className="pl-10"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                      />
                    </div>
                  </div>
                  
                  {planDetails && (
                    <div className="p-3 bg-solana/10 rounded-lg text-center">
                      <p className="text-sm font-medium">Selected Plan: {planDetails.name}</p>
                      <p className="text-lg font-bold mt-1">{planDetails.price} SOL</p>
                      <p className="text-xs text-muted-foreground">{planDetails.duration}</p>
                    </div>
                  )}
                  
                  {!planDetails && (
                    <div className="space-y-2">
                      <Label>Select a Subscription Plan</Label>
                      <div className="grid grid-cols-2 gap-2">
                        {subscriptionPlans.map((plan) => (
                          <Button
                            key={plan.id}
                            type="button"
                            variant={selectedPlan === plan.id ? "default" : "outline"}
                            className={selectedPlan === plan.id ? "bg-solana hover:bg-solana/90" : ""}
                            onClick={() => setSelectedPlan(plan.id)}
                          >
                            {plan.name} - {plan.price} SOL
                          </Button>
                        ))}
                      </div>
                    </div>
                  )}
                  
                  <Button 
                    type="submit" 
                    className="w-full bg-solana hover:bg-solana/90 text-white"
                    disabled={isLoading || !selectedPlan}
                  >
                    {isLoading ? "Creating Account..." : "Register & Checkout"}
                  </Button>
                </form>
              </TabsContent>
            </Tabs>
          </CardContent>
          <CardFooter className="flex justify-center text-sm text-muted-foreground">
            {activeTab === 'login' ? (
              <p>Don't have an account? <Button variant="link" className="p-0 h-auto" onClick={() => setActiveTab('register')}>Register</Button></p>
            ) : (
              <p>Already have an account? <Button variant="link" className="p-0 h-auto" onClick={() => setActiveTab('login')}>Log in</Button></p>
            )}
          </CardFooter>
        </Card>
      </div>
    </Layout>
  );
};

export default Auth;
