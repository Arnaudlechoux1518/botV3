import { Wallet, Transaction, SubscriptionPlan, SimulationStats } from './types';

// Mock wallets
export const mockWallets: Wallet[] = [
  {
    id: '1',
    address: 'A1B2C3D4E5F6G7H8I9J0K1L2M3N4O5P6Q7R8S9T0',
    privateKey: '••••••••••••••••••••••••••••••••••••••••••••••••',
    balance: 2.45,
  },
  {
    id: '2',
    address: 'B2C3D4E5F6G7H8I9J0K1L2M3N4O5P6Q7R8S9T0U1',
    privateKey: '••••••••••••••••••••••••••••••••••••••••••••••••',
    balance: 1.78,
  },
  {
    id: '3',
    address: 'C3D4E5F6G7H8I9J0K1L2M3N4O5P6Q7R8S9T0U1V2',
    privateKey: '••••••••••••••••••••••••••••••••••••••••••••••••',
    balance: 3.21,
  },
  {
    id: '4',
    address: 'D4E5F6G7H8I9J0K1L2M3N4O5P6Q7R8S9T0U1V2W3',
    privateKey: '••••••••••••••••••••••••••••••••••••••••••••••••',
    balance: 0.98,
  },
  {
    id: '5',
    address: 'E5F6G7H8I9J0K1L2M3N4O5P6Q7R8S9T0U1V2W3X4',
    privateKey: '••••••••••••••••••••••••••••••••••••••••••••••••',
    balance: 1.52,
  },
];

// Mock transactions
export const mockTransactions: Transaction[] = [
  {
    id: '1',
    timestamp: new Date(Date.now() - 120000),
    fromWallet: 'A1B2C3...S9T0',
    toWallet: 'B2C3D4...T0U1',
    amount: 0.05,
    status: 'completed',
    txHash: '8X7Y6Z5A4B3C2D1E0F9G8H7I6J5K4L3M2N1O0P9Q8R7',
  },
  {
    id: '2',
    timestamp: new Date(Date.now() - 80000),
    fromWallet: 'C3D4E5...U1V2',
    toWallet: 'D4E5F6...V2W3',
    amount: 0.02,
    status: 'completed',
    txHash: '7Y6Z5A4B3C2D1E0F9G8H7I6J5K4L3M2N1O0P9Q8R7S6',
  },
  {
    id: '3',
    timestamp: new Date(Date.now() - 40000),
    fromWallet: 'B2C3D4...T0U1',
    toWallet: 'E5F6G7...W3X4',
    amount: 0.07,
    status: 'completed',
    txHash: '6Z5A4B3C2D1E0F9G8H7I6J5K4L3M2N1O0P9Q8R7S6T5',
  },
  {
    id: '4',
    timestamp: new Date(Date.now() - 10000),
    fromWallet: 'D4E5F6...V2W3',
    toWallet: 'A1B2C3...S9T0',
    amount: 0.03,
    status: 'pending',
  },
];

// Mock subscription plans
export const subscriptionPlans: SubscriptionPlan[] = [
  {
    id: '2h',
    name: 'Basic',
    duration: '2 Hours',
    price: 0.3,
    features: [
      'Multi wallet trading',
      'Real-time monitoring',
      'Transaction logs',
      'Analytics dashboard',
      'Priority support',
    ],
  },
  {
    id: '1d',
    name: 'Standard',
    duration: '1 Day',
    price: 0.6,
    features: [
      'Multi wallet trading',
      'Real-time monitoring',
      'Transaction logs',
      'Analytics dashboard',
      'Priority support',
    ],
  },
  {
    id: '1m',
    name: 'Premium',
    duration: '1 Month',
    price: 2,
    features: [
      'Multi wallet trading',
      'Real-time monitoring',
      'Transaction logs',
      'Analytics dashboard',
      'Priority support',
    ],
  },
  {
    id: '1y',
    name: 'Enterprise',
    duration: '1 Year',
    price: 5,
    features: [
      'Multi wallet trading',
      'Real-time monitoring',
      'Transaction logs',
      'Analytics dashboard',
      'Priority support',
    ],
  },
];

// Mock simulation stats
export const mockStats: SimulationStats = {
  totalVolume: 0.17,
  transactionCount: 4,
  activeWallets: 5,
  averageAmount: 0.04,
  timeRemaining: 7200000, // 2 hours in milliseconds
};
