
export interface Wallet {
  id: string;
  address: string;
  privateKey: string;
  balance: number;
}

export interface Transaction {
  id: string;
  timestamp: Date;
  fromWallet: string;
  toWallet: string;
  amount: number;
  status: 'pending' | 'completed' | 'failed';
  txHash?: string;
}

export interface SimulationConfig {
  tokenAddress: string;
  minAmount: number;
  maxAmount: number;
  minDelay: number;
  maxDelay: number;
  duration: Duration;
}

export type Duration = '2h' | '1d' | '1m' | '1y';

export interface SubscriptionPlan {
  id: Duration;
  name: string;
  duration: string;
  price: number;
  features: string[];
}

export interface SimulationStats {
  totalVolume: number;
  transactionCount: number;
  activeWallets: number;
  averageAmount: number;
  timeRemaining: number;
}
