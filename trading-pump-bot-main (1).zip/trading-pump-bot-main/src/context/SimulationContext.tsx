
import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { Wallet, Transaction, SimulationConfig, Duration, SimulationStats } from '@/lib/types';
import { mockWallets, mockTransactions, mockStats } from '@/lib/mockData';
import { toast } from '@/components/ui/use-toast';

interface SimulationContextType {
  wallets: Wallet[];
  transactions: Transaction[];
  config: SimulationConfig;
  stats: SimulationStats;
  isRunning: boolean;
  selectedPlan: Duration | null;
  addWallet: (wallet: Omit<Wallet, 'id'>) => void;
  removeWallet: (id: string) => void;
  updateConfig: (config: Partial<SimulationConfig>) => void;
  startSimulation: () => void;
  stopSimulation: () => void;
  selectPlan: (plan: Duration) => void;
}

const defaultConfig: SimulationConfig = {
  tokenAddress: '',
  minAmount: 0.01,
  maxAmount: 0.1,
  minDelay: 10,
  maxDelay: 60,
  duration: '2h',
};

const SimulationContext = createContext<SimulationContextType | undefined>(undefined);

export const SimulationProvider = ({ children }: { children: ReactNode }) => {
  const [wallets, setWallets] = useState<Wallet[]>(mockWallets);
  const [transactions, setTransactions] = useState<Transaction[]>(mockTransactions);
  const [config, setConfig] = useState<SimulationConfig>(defaultConfig);
  const [stats, setStats] = useState<SimulationStats>(mockStats);
  const [isRunning, setIsRunning] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<Duration | null>(null);
  const [simulationInterval, setSimulationInterval] = useState<NodeJS.Timeout | null>(null);

  // Clean up interval on unmount
  useEffect(() => {
    return () => {
      if (simulationInterval) clearInterval(simulationInterval);
    };
  }, [simulationInterval]);

  // Helper function to generate random number between min and max
  const random = (min: number, max: number) => {
    return Math.random() * (max - min) + min;
  };

  // Add a new wallet
  const addWallet = (wallet: Omit<Wallet, 'id'>) => {
    const newWallet = {
      ...wallet,
      id: Date.now().toString(),
    };
    setWallets([...wallets, newWallet]);
    toast({
      title: "Wallet Added",
      description: `Wallet has been added successfully.`,
    });
  };

  // Remove a wallet
  const removeWallet = (id: string) => {
    setWallets(wallets.filter(wallet => wallet.id !== id));
    toast({
      title: "Wallet Removed",
      description: `Wallet has been removed successfully.`,
    });
  };

  // Update simulation configuration
  const updateConfig = (newConfig: Partial<SimulationConfig>) => {
    setConfig({ ...config, ...newConfig });
  };

  // Generate a mock transaction
  const generateTransaction = () => {
    if (wallets.length < 2) return;

    // Select random sender and receiver
    const senderIndex = Math.floor(Math.random() * wallets.length);
    let receiverIndex;
    do {
      receiverIndex = Math.floor(Math.random() * wallets.length);
    } while (receiverIndex === senderIndex);

    const sender = wallets[senderIndex];
    const receiver = wallets[receiverIndex];

    // Generate random amount
    const amount = parseFloat(random(config.minAmount, config.maxAmount).toFixed(5));

    // Create new transaction
    const newTransaction: Transaction = {
      id: Date.now().toString(),
      timestamp: new Date(),
      fromWallet: `${sender.address.substring(0, 7)}...${sender.address.substring(sender.address.length - 4)}`,
      toWallet: `${receiver.address.substring(0, 7)}...${receiver.address.substring(receiver.address.length - 4)}`,
      amount,
      status: 'pending',
    };

    // Add new transaction
    setTransactions(prev => [newTransaction, ...prev]);

    // Update stats
    setStats(prev => ({
      ...prev,
      totalVolume: parseFloat((prev.totalVolume + amount).toFixed(5)),
      transactionCount: prev.transactionCount + 1,
      averageAmount: parseFloat(((prev.totalVolume + amount) / (prev.transactionCount + 1)).toFixed(5)),
    }));

    // Update transaction status after 2 seconds
    setTimeout(() => {
      setTransactions(prev => 
        prev.map(tx => 
          tx.id === newTransaction.id 
            ? { 
                ...tx, 
                status: 'completed',
                txHash: Array(48).fill(0).map(() => Math.floor(Math.random() * 16).toString(16)).join('')
              } 
            : tx
        )
      );
    }, 2000);
  };

  // Start simulation
  const startSimulation = () => {
    if (!selectedPlan) {
      toast({
        title: "No Plan Selected",
        description: "Please select a subscription plan before starting the simulation.",
        variant: "destructive",
      });
      return;
    }

    if (wallets.length < 2) {
      toast({
        title: "Not Enough Wallets",
        description: "You need at least 2 wallets to start the simulation.",
        variant: "destructive",
      });
      return;
    }

    if (!config.tokenAddress) {
      toast({
        title: "Token Address Required",
        description: "Please enter a token address before starting the simulation.",
        variant: "destructive",
      });
      return;
    }

    setIsRunning(true);
    toast({
      title: "Simulation Started",
      description: "The trading bot simulation has been started successfully.",
    });

    // Generate initial transaction
    generateTransaction();

    // Set up interval for generating transactions
    const interval = setInterval(() => {
      generateTransaction();
      
      // Update remaining time
      setStats(prev => ({
        ...prev,
        timeRemaining: Math.max(0, prev.timeRemaining - (config.maxDelay * 1000)),
      }));
    }, random(config.minDelay * 1000, config.maxDelay * 1000));

    setSimulationInterval(interval);

    // Stop simulation after duration
    const durationMap = {
      '2h': 2 * 60 * 60 * 1000,
      '1d': 24 * 60 * 60 * 1000,
      '1m': 30 * 24 * 60 * 60 * 1000,
      '1y': 365 * 24 * 60 * 60 * 1000,
    };

    setTimeout(() => {
      stopSimulation();
      toast({
        title: "Simulation Completed",
        description: "The simulation has ended as the subscription period is over.",
      });
    }, durationMap[selectedPlan]);
  };

  // Stop simulation
  const stopSimulation = () => {
    if (simulationInterval) {
      clearInterval(simulationInterval);
      setSimulationInterval(null);
    }
    setIsRunning(false);
    toast({
      title: "Simulation Stopped",
      description: "The trading bot simulation has been stopped.",
    });
  };

  // Select subscription plan
  const selectPlan = (plan: Duration) => {
    setSelectedPlan(plan);
    updateConfig({ duration: plan });

    // Set appropriate timeRemaining based on selected plan
    const durationMilliseconds = {
      '2h': 2 * 60 * 60 * 1000,
      '1d': 24 * 60 * 60 * 1000,
      '1m': 30 * 24 * 60 * 60 * 1000,
      '1y': 365 * 24 * 60 * 60 * 1000,
    };

    setStats(prev => ({
      ...prev,
      timeRemaining: durationMilliseconds[plan],
    }));

    toast({
      title: "Plan Selected",
      description: `You've selected the ${plan} plan.`,
    });
  };

  return (
    <SimulationContext.Provider
      value={{
        wallets,
        transactions,
        config,
        stats,
        isRunning,
        selectedPlan,
        addWallet,
        removeWallet,
        updateConfig,
        startSimulation,
        stopSimulation,
        selectPlan,
      }}
    >
      {children}
    </SimulationContext.Provider>
  );
};

export const useSimulation = () => {
  const context = useContext(SimulationContext);
  if (!context) {
    throw new Error('useSimulation must be used within a SimulationProvider');
  }
  return context;
};
