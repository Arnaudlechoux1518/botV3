
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { toast } from '@/components/ui/use-toast';

interface User {
  email: string;
  subscription: {
    plan: string;
    status: 'active' | 'expired' | 'cancelled';
    expiresAt: Date;
  } | null;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (email: string, password: string, planId: string) => Promise<void>;
  logout: () => void;
  checkoutSubscription: (planId: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  // Check for existing session on load
  useEffect(() => {
    const storedUser = localStorage.getItem('pumpbot_user');
    if (storedUser) {
      try {
        const parsedUser = JSON.parse(storedUser);
        setUser(parsedUser);
        setIsAuthenticated(true);
      } catch (error) {
        console.error('Failed to parse stored user:', error);
        localStorage.removeItem('pumpbot_user');
      }
    }
    setIsLoading(false);
  }, []);

  // Login function - would connect to a real backend in production
  const login = async (email: string, password: string) => {
    setIsLoading(true);
    try {
      // Mock API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Mock successful login with dummy user data
      const mockUser: User = {
        email,
        subscription: {
          plan: '1m',
          status: 'active',
          expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days from now
        },
      };
      
      setUser(mockUser);
      setIsAuthenticated(true);
      localStorage.setItem('pumpbot_user', JSON.stringify(mockUser));
      
      toast({
        title: "Login Successful",
        description: "Welcome back to Pump.fun Bot!",
      });
    } catch (error) {
      console.error('Login failed:', error);
      toast({
        title: "Login Failed",
        description: "Invalid email or password. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Register function - would connect to a real backend in production
  const register = async (email: string, password: string, planId: string) => {
    setIsLoading(true);
    try {
      // Mock API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Mock successful registration
      toast({
        title: "Registration Successful",
        description: "Please complete the checkout process to activate your subscription.",
      });
      
      // After registration, initiate checkout
      await checkoutSubscription(planId);
    } catch (error) {
      console.error('Registration failed:', error);
      toast({
        title: "Registration Failed",
        description: "Could not create your account. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Mock Stripe checkout process
  const checkoutSubscription = async (planId: string) => {
    setIsLoading(true);
    try {
      // Mock API call to create a Stripe checkout session
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      alert("In a real app, this would redirect to Stripe checkout. After payment, the user would be redirected back and authenticated.");
      
      // Mock successful payment
      const mockUser: User = {
        email: "user@example.com", // In a real app, this would come from the registration form
        subscription: {
          plan: planId,
          status: 'active',
          expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days from now
        },
      };
      
      setUser(mockUser);
      setIsAuthenticated(true);
      localStorage.setItem('pumpbot_user', JSON.stringify(mockUser));
      
      toast({
        title: "Subscription Activated",
        description: "Your subscription has been activated successfully!",
      });
    } catch (error) {
      console.error('Checkout failed:', error);
      toast({
        title: "Checkout Failed",
        description: "Could not process your payment. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Logout function
  const logout = () => {
    setUser(null);
    setIsAuthenticated(false);
    localStorage.removeItem('pumpbot_user');
    toast({
      title: "Logged Out",
      description: "You have been logged out successfully.",
    });
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated,
        isLoading,
        login,
        register,
        logout,
        checkoutSubscription,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
