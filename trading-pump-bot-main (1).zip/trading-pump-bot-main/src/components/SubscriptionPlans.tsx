import React from 'react';
import { CrownIcon, CheckIcon, ClockIcon, RocketIcon } from 'lucide-react';
import { useSimulation } from '@/context/SimulationContext';
import { useAuth } from '@/context/AuthContext';
import { useNavigate } from 'react-router-dom';
import { subscriptionPlans } from '@/lib/mockData';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Duration } from '@/lib/types';
import { Progress } from '@/components/ui/progress';

const SubscriptionPlans = () => {
  const { selectPlan, selectedPlan, isRunning, stats } = useSimulation();
  const { isAuthenticated, user } = useAuth();
  const navigate = useNavigate();
  const [timeDisplay, setTimeDisplay] = React.useState('');
  
  React.useEffect(() => {
    const formatTimeRemaining = () => {
      const ms = stats.timeRemaining;
      
      const days = Math.floor(ms / (24 * 60 * 60 * 1000));
      const hours = Math.floor((ms % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000));
      const minutes = Math.floor((ms % (60 * 60 * 1000)) / (60 * 1000));
      const seconds = Math.floor((ms % (60 * 1000)) / 1000);
      
      if (days > 0) {
        return `${days}d ${hours}h ${minutes}m`;
      } else if (hours > 0) {
        return `${hours}h ${minutes}m ${seconds}s`;
      } else {
        return `${minutes}m ${seconds}s`;
      }
    };
    
    const intervalId = setInterval(() => {
      setTimeDisplay(formatTimeRemaining());
    }, 1000);
    
    setTimeDisplay(formatTimeRemaining());
    
    return () => clearInterval(intervalId);
  }, [stats.timeRemaining]);

  const handlePlanSelect = (planId: string) => {
    if (isAuthenticated) {
      selectPlan(planId as Duration);
    } else {
      navigate(`/auth?plan=${planId}`);
    }
  };

  React.useEffect(() => {
    if (isAuthenticated && user?.subscription && !selectedPlan) {
      selectPlan(user.subscription.plan as Duration);
    }
  }, [isAuthenticated, user, selectedPlan, selectPlan]);

  if (isAuthenticated && user?.subscription) {
    return (
      <div className="neo-card p-6 animate-scale-in">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold flex items-center">
            <ClockIcon size={20} className="mr-2 text-solana-secondary" />
            Subscription Time Remaining
          </h2>
        </div>
        
        <div className="bg-white dark:bg-pump-light/10 border border-gray-100 dark:border-pump-light/20 rounded-xl p-6">
          <div className="text-center space-y-4">
            <div className="text-4xl font-bold text-solana-secondary">
              {timeDisplay}
            </div>
            <p className="text-muted-foreground">
              Your {user.subscription.plan.toUpperCase()} plan will expire on {new Date(user.subscription.expiresAt).toLocaleDateString()}
            </p>
            <Progress 
              value={(stats.timeRemaining / getDurationInMs(user.subscription.plan as Duration)) * 100}
              className="h-2 mt-2 bg-gray-100 dark:bg-pump-light/10"
            />
          </div>
        </div>
      </div>
    );
  }

  function getDurationInMs(duration: Duration): number {
    const durationMap = {
      '2h': 2 * 60 * 60 * 1000,
      '1d': 24 * 60 * 60 * 1000,
      '1m': 30 * 24 * 60 * 60 * 1000,
      '1y': 365 * 24 * 60 * 60 * 1000,
    };
    return durationMap[duration];
  }

  return (
    <div className="neo-card p-6 animate-scale-in">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold flex items-center">
          <RocketIcon size={20} className="mr-2 text-solana-secondary" />
          Subscription Plans
        </h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {subscriptionPlans.map((plan) => (
          <div
            key={plan.id}
            className={cn(
              "relative p-5 rounded-xl border transition-all hover:shadow-lg cursor-pointer overflow-hidden",
              selectedPlan === plan.id
                ? "border-solana-secondary bg-solana-secondary/10 dark:bg-solana-secondary/20"
                : "border-gray-200 dark:border-pump-light/20 bg-white dark:bg-pump-light/5",
              isRunning && "pointer-events-none opacity-50"
            )}
            onClick={() => !isRunning && handlePlanSelect(plan.id)}
          >
            {plan.id === '1y' && (
              <div className="absolute -right-12 top-5 bg-solana-secondary text-white text-xs py-1 px-10 transform rotate-45">
                Best Value
              </div>
            )}
            
            <div className="text-center space-y-1 mb-3">
              <h3 className="font-semibold text-lg">{plan.name}</h3>
              <p className="text-sm text-muted-foreground">{plan.duration}</p>
            </div>
            
            <div className="text-center my-4">
              <span className="text-3xl font-bold text-solana-secondary">{plan.price}</span>
              <span className="text-lg ml-1">SOL</span>
            </div>
            
            <ul className="space-y-2 mt-4">
              <li className="flex items-start text-sm">
                <CheckIcon size={16} className="mr-2 mt-1 text-solana-secondary shrink-0" />
                <span><span className="font-medium">Multi wallet trading:</span> Generate transactions across up to 25 wallets, optimizing liquidity and enhancing market dynamics with natural trading patterns</span>
              </li>
              {plan.features.filter(feature => feature !== 'Multi wallet trading').map((feature, index) => (
                <li key={index} className="flex items-center text-sm">
                  <CheckIcon size={16} className="mr-2 text-solana-secondary shrink-0" />
                  {feature}
                </li>
              ))}
            </ul>
            
            {selectedPlan === plan.id ? (
              <div className="absolute bottom-0 left-0 right-0 h-1 bg-solana-secondary" />
            ) : (
              <div className="mt-4 text-center">
                <Button 
                  variant="outline" 
                  size="sm"
                  className="w-full hover:bg-solana-secondary/10 hover:text-solana-secondary hover:border-solana-secondary"
                  onClick={(e) => {
                    e.stopPropagation();
                    handlePlanSelect(plan.id);
                  }}
                >
                  {isAuthenticated ? "Select Plan" : "Subscribe"}
                </Button>
              </div>
            )}
          </div>
        ))}
      </div>

      {!isAuthenticated && (
        <div className="mt-6 p-4 bg-gray-50 dark:bg-pump-light/5 rounded-lg border border-gray-200 dark:border-pump-light/20 text-center">
          <p className="text-sm text-muted-foreground">
            Already purchased a subscription? <Button variant="link" className="p-0 h-auto text-solana-secondary" onClick={() => navigate('/auth')}>Log in here</Button>
          </p>
        </div>
      )}
    </div>
  );
};

export default SubscriptionPlans;
