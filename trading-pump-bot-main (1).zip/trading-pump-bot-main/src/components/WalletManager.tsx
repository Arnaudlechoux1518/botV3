
import React, { useState } from 'react';
import { PlusCircleIcon, Trash2Icon, EyeIcon, EyeOffIcon, WalletIcon } from 'lucide-react';
import { useSimulation } from '@/context/SimulationContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from '@/components/ui/use-toast';

const WalletManager = () => {
  const { wallets, addWallet, removeWallet, isRunning } = useSimulation();
  const [address, setAddress] = useState('');
  const [privateKey, setPrivateKey] = useState('');
  const [showPrivateKey, setShowPrivateKey] = useState<Record<string, boolean>>({});

  const togglePrivateKeyVisibility = (id: string) => {
    setShowPrivateKey(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  const handleAddWallet = () => {
    if (!address || !privateKey) {
      toast({
        title: "Missing Fields",
        description: "Please provide both address and private key.",
        variant: "destructive",
      });
      return;
    }

    addWallet({
      address,
      privateKey,
      balance: parseFloat((Math.random() * 3 + 0.5).toFixed(2)),
    });

    setAddress('');
    setPrivateKey('');
  };

  const generateRandomWallet = () => {
    // This is a mock function - in reality, would call Solana API
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let addr = '';
    let key = '';
    
    for (let i = 0; i < 40; i++) {
      addr += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    
    for (let i = 0; i < 50; i++) {
      key += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    
    setAddress(addr);
    setPrivateKey(key);
  };

  return (
    <div className="neo-card p-6 animate-scale-in">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold flex items-center">
          <WalletIcon size={20} className="mr-2 text-solana" />
          Wallet Management
        </h2>
        <span className="text-sm px-3 py-1 bg-muted dark:bg-pump-light/30 rounded-full">
          {wallets.length} / 25 Wallets
        </span>
      </div>

      {!isRunning && (
        <div className="space-y-4 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Wallet Address</label>
              <Input
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="Enter wallet address"
                className="font-mono text-sm"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Private Key</label>
              <div className="relative">
                <Input
                  type="password"
                  value={privateKey}
                  onChange={(e) => setPrivateKey(e.target.value)}
                  placeholder="Enter private key"
                  className="font-mono text-sm pr-10"
                />
              </div>
            </div>
          </div>
          
          <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2">
            <Button
              onClick={handleAddWallet}
              disabled={wallets.length >= 25 || !address || !privateKey}
              className="w-full sm:w-auto flex-1"
            >
              <PlusCircleIcon size={16} className="mr-2" />
              Add Wallet
            </Button>
            <Button
              variant="secondary"
              onClick={generateRandomWallet}
              disabled={wallets.length >= 25}
              className="w-full sm:w-auto flex-1"
            >
              Generate Random Wallet
            </Button>
          </div>
        </div>
      )}

      <div className="space-y-3 max-h-[300px] overflow-y-auto pr-2">
        {wallets.map((wallet) => (
          <div
            key={wallet.id}
            className="p-3 rounded-lg bg-white dark:bg-pump-light/10 border border-gray-100 dark:border-pump-light/20 shadow-sm transition-all hover:shadow-md"
          >
            <div className="flex justify-between items-start">
              <div className="space-y-1">
                <p className="text-sm font-medium flex items-center">
                  <span className="h-2 w-2 rounded-full bg-green-400 mr-2"></span>
                  Wallet {wallets.findIndex((w) => w.id === wallet.id) + 1}
                </p>
                <p className="text-xs font-mono text-muted-foreground break-all">
                  {wallet.address}
                </p>
                <p className="text-xs font-mono text-muted-foreground mt-1">
                  {showPrivateKey[wallet.id] ? wallet.privateKey : '••••••••••••••••••••••••••••••••••••••••••••••••'}
                  <button
                    onClick={() => togglePrivateKeyVisibility(wallet.id)}
                    className="ml-2 text-gray-500 hover:text-gray-700 dark:hover:text-gray-300"
                  >
                    {showPrivateKey[wallet.id] ? (
                      <EyeOffIcon size={14} />
                    ) : (
                      <EyeIcon size={14} />
                    )}
                  </button>
                </p>
              </div>
              
              <div className="flex items-center space-x-3">
                <div className="text-right">
                  <p className="text-sm font-medium">{wallet.balance} SOL</p>
                </div>
                
                {!isRunning && (
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => removeWallet(wallet.id)}
                    className="h-8 w-8 text-red-500 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-900/20"
                  >
                    <Trash2Icon size={16} />
                  </Button>
                )}
              </div>
            </div>
          </div>
        ))}
        
        {wallets.length === 0 && (
          <div className="text-center py-6 bg-muted/40 dark:bg-pump-light/5 rounded-lg border border-dashed border-muted-foreground/20">
            <p className="text-muted-foreground">No wallets added yet</p>
            <p className="text-sm text-muted-foreground mt-1">
              Add wallets to start volume bot
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default WalletManager;
