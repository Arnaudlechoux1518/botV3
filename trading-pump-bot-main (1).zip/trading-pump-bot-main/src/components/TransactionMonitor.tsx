
import React, { useRef, useEffect } from 'react';
import { ArrowDownIcon, ArrowUpIcon, ActivityIcon, ClockIcon, CheckCircleIcon, XCircleIcon } from 'lucide-react';
import { useSimulation } from '@/context/SimulationContext';
import { formatDistanceToNow } from 'date-fns';

const TransactionMonitor = () => {
  const { transactions, isRunning } = useSimulation();
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = 0;
    }
  }, [transactions]);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircleIcon size={16} className="text-green-500" />;
      case 'failed':
        return <XCircleIcon size={16} className="text-red-500" />;
      case 'pending':
      default:
        return <ClockIcon size={16} className="text-amber-500 animate-pulse" />;
    }
  };

  return (
    <div className="neo-card p-6 animate-scale-in h-full">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold flex items-center">
          <ActivityIcon size={20} className="mr-2 text-solana" />
          Transaction Monitor
        </h2>
        <div className="flex items-center space-x-2">
          <div className={`w-2 h-2 rounded-full ${isRunning ? 'bg-green-500 animate-pulse' : 'bg-gray-400'}`}></div>
          <span className="text-sm">{isRunning ? 'Live' : 'Idle'}</span>
        </div>
      </div>

      <div 
        ref={scrollRef}
        className="space-y-3 overflow-y-auto max-h-[400px] pr-2"
      >
        {transactions.length > 0 ? (
          transactions.map((tx) => (
            <div
              key={tx.id}
              className={`p-3 rounded-lg border transition-all ${
                tx.status === 'pending'
                  ? 'bg-amber-50/30 dark:bg-amber-900/10 border-amber-200 dark:border-amber-700/30 animate-pulse-subtle'
                  : tx.status === 'completed'
                  ? 'bg-white dark:bg-pump-light/10 border-gray-100 dark:border-pump-light/20'
                  : 'bg-red-50 dark:bg-red-900/10 border-red-200 dark:border-red-700/30'
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="space-y-1 flex-1">
                  <div className="flex items-center text-sm font-medium">
                    {getStatusIcon(tx.status)}
                    <span className="ml-2">
                      {formatDistanceToNow(new Date(tx.timestamp), { addSuffix: true })}
                    </span>
                  </div>
                  
                  <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                    <span className="font-mono">{tx.fromWallet}</span>
                    <ArrowRightIcon />
                    <span className="font-mono">{tx.toWallet}</span>
                  </div>
                  
                  {tx.txHash && (
                    <p className="text-xs font-mono text-muted-foreground truncate">
                      TX: {tx.txHash.substring(0, 8)}...{tx.txHash.substring(tx.txHash.length - 8)}
                    </p>
                  )}
                </div>
                
                <div className="text-right ml-4">
                  <p className="text-sm font-medium">{tx.amount.toFixed(5)} SOL</p>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-10 bg-muted/40 dark:bg-pump-light/5 rounded-lg border border-dashed border-muted-foreground/20">
            <p className="text-muted-foreground">No transactions yet</p>
            <p className="text-sm text-muted-foreground mt-1">
              Start the simulation to see transactions
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

// Arrow Right Icon Component
const ArrowRightIcon = () => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-muted-foreground">
    <path d="M8 3L14 8L8 13M14 8H2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

export default TransactionMonitor;
