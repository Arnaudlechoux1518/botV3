
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import { BarChart3Icon, Clock10Icon } from 'lucide-react';
import { useSimulation } from '@/context/SimulationContext';

const formatTime = (ms: number) => {
  const seconds = Math.floor((ms / 1000) % 60);
  const minutes = Math.floor((ms / (1000 * 60)) % 60);
  const hours = Math.floor((ms / (1000 * 60 * 60)) % 24);
  const days = Math.floor(ms / (1000 * 60 * 60 * 24));

  if (days > 0) return `${days}d ${hours}h`;
  if (hours > 0) return `${hours}h ${minutes}m`;
  return `${minutes}m ${seconds}s`;
};

const Analytics = () => {
  const { stats, transactions, isRunning } = useSimulation();

  // Generate chart data based on transactions
  const generateVolumeData = () => {
    // Group transactions by hour
    const lastTransactions = transactions.slice(0, 10).reverse();
    return lastTransactions.map((tx, index) => ({
      name: `T${index + 1}`,
      volume: tx.amount,
    }));
  };

  // Dummy data for cumulative chart
  const cumulativeData = [
    { name: 'Start', volume: 0 },
    ...transactions.slice(0, 10).reverse().map((tx, index) => ({
      name: `T${index + 1}`,
      volume: parseFloat((0.04 * (index + 1)).toFixed(2)),
    })),
  ];

  return (
    <div className="neo-card p-6 animate-scale-in">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold flex items-center">
          <BarChart3Icon size={20} className="mr-2 text-solana" />
          Analytics
        </h2>
        <div className="flex items-center space-x-2">
          <Clock10Icon size={16} className="text-muted-foreground" />
          <span className="text-sm text-muted-foreground">
            {isRunning ? (
              <span className="font-medium">Time Remaining: {formatTime(stats.timeRemaining)}</span>
            ) : (
              "Inactive"
            )}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <StatCard
          title="Total Volume"
          value={`${stats.totalVolume.toFixed(5)} SOL`}
          description="Total trading volume generated"
          trend="up"
          isRunning={isRunning}
        />
        <StatCard
          title="Transactions"
          value={stats.transactionCount.toString()}
          description="Total transactions executed"
          trend="up"
          isRunning={isRunning}
        />
        <StatCard
          title="Active Wallets"
          value={stats.activeWallets.toString()}
          description="Number of wallets in use"
          trend="neutral"
          isRunning={isRunning}
        />
        <StatCard
          title="Avg. Amount"
          value={`${stats.averageAmount.toFixed(5)} SOL`}
          description="Average transaction amount"
          trend="up"
          isRunning={isRunning}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-pump-light/5 rounded-xl p-4 border border-gray-100 dark:border-pump-light/20">
          <h3 className="text-sm font-medium mb-2">Transaction Volume</h3>
          <div className="h-[200px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={generateVolumeData()}>
                <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'rgba(255, 255, 255, 0.9)', 
                    borderRadius: '8px',
                    border: 'none',
                    boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
                    fontSize: '12px'
                  }} 
                  formatter={(value: number) => [`${value.toFixed(5)} SOL`, 'Volume']}
                />
                <Bar dataKey="volume" fill="#9945FF" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
        
        <div className="bg-white dark:bg-pump-light/5 rounded-xl p-4 border border-gray-100 dark:border-pump-light/20">
          <h3 className="text-sm font-medium mb-2">Cumulative Volume</h3>
          <div className="h-[200px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={cumulativeData}>
                <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'rgba(255, 255, 255, 0.9)', 
                    borderRadius: '8px',
                    border: 'none',
                    boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
                    fontSize: '12px'
                  }} 
                  formatter={(value: number) => [`${value.toFixed(2)} SOL`, 'Volume']}
                />
                <Line 
                  type="monotone" 
                  dataKey="volume" 
                  stroke="#14F195" 
                  strokeWidth={2}
                  dot={{ fill: '#14F195', r: 4 }}
                  activeDot={{ r: 6, stroke: '#14F195', strokeWidth: 2 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

interface StatCardProps {
  title: string;
  value: string;
  description: string;
  trend: 'up' | 'down' | 'neutral';
  isRunning: boolean;
}

const StatCard = ({ title, value, description, trend, isRunning }: StatCardProps) => {
  return (
    <div className="bg-white dark:bg-pump-light/5 rounded-xl p-4 border border-gray-100 dark:border-pump-light/20">
      <h3 className="text-sm font-medium text-muted-foreground">{title}</h3>
      <div className="flex items-end justify-between mt-1">
        <p className={`text-2xl font-bold ${isRunning && trend === 'up' ? 'animate-pulse-subtle' : ''}`}>
          {value}
        </p>
        {isRunning && trend !== 'neutral' && (
          <span className={`text-xs ${trend === 'up' ? 'text-green-500' : 'text-red-500'}`}>
            {trend === 'up' ? (
              <span className="flex items-center">
                <ArrowUpIcon />
                {Math.floor(Math.random() * 10) + 1}%
              </span>
            ) : (
              <span className="flex items-center">
                <ArrowDownIcon />
                {Math.floor(Math.random() * 10) + 1}%
              </span>
            )}
          </span>
        )}
      </div>
      <p className="text-xs text-muted-foreground mt-1">{description}</p>
    </div>
  );
};

// Arrow Icons
const ArrowUpIcon = () => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-green-500">
    <path d="M8 12V4M8 4L4 8M8 4L12 8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

const ArrowDownIcon = () => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-red-500">
    <path d="M8 4V12M8 12L4 8M8 12L12 8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

export default Analytics;
