
import React from 'react';
import { Settings2Icon } from 'lucide-react';
import { useSimulation } from '@/context/SimulationContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Slider } from '@/components/ui/slider';
import { toast } from '@/components/ui/use-toast';

const SimulationConfig = () => {
  const { config, updateConfig, isRunning } = useSimulation();

  const handleTokenAddress = (e: React.ChangeEvent<HTMLInputElement>) => {
    updateConfig({ tokenAddress: e.target.value });
  };

  const handleAmountRange = (value: number[]) => {
    updateConfig({
      minAmount: value[0],
      maxAmount: value[1],
    });
  };

  const handleDelayRange = (value: number[]) => {
    updateConfig({
      minDelay: value[0],
      maxDelay: value[1],
    });
  };

  const randomizeConfig = () => {
    const minAmount = parseFloat((Math.random() * 0.05 + 0.01).toFixed(3));
    const maxAmount = parseFloat((Math.random() * 0.1 + minAmount + 0.01).toFixed(3));
    const minDelay = Math.floor(Math.random() * 10 + 5);
    const maxDelay = Math.floor(Math.random() * 50 + minDelay + 10);

    updateConfig({
      minAmount,
      maxAmount,
      minDelay,
      maxDelay,
    });

    toast({
      title: "Configuration Randomized",
      description: "Simulation parameters have been randomized.",
    });
  };

  return (
    <div className="neo-card p-6 animate-scale-in">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold flex items-center">
          <Settings2Icon size={20} className="mr-2 text-solana" />
          Simulation Configuration
        </h2>
        {!isRunning && (
          <Button variant="outline" size="sm" onClick={randomizeConfig}>
            Randomize
          </Button>
        )}
      </div>

      <div className="space-y-6">
        <div className="space-y-2">
          <label className="text-sm font-medium">Token Address</label>
          <Input
            value={config.tokenAddress}
            onChange={handleTokenAddress}
            placeholder="Enter token address from Pump.fun"
            disabled={isRunning}
            className="font-mono text-sm"
          />
        </div>

        <div className="space-y-4">
          <div className="space-y-2">
            <div className="flex justify-between">
              <label className="text-sm font-medium">Transaction Amount (SOL)</label>
              <div className="text-sm text-muted-foreground">
                {config.minAmount.toFixed(3)} - {config.maxAmount.toFixed(3)} SOL
              </div>
            </div>
            <Slider
              disabled={isRunning}
              value={[config.minAmount, config.maxAmount]}
              min={0.001}
              max={0.5}
              step={0.001}
              onValueChange={handleAmountRange}
              className="my-4"
            />
          </div>

          <div className="space-y-2">
            <div className="flex justify-between">
              <label className="text-sm font-medium">Transaction Delay (seconds)</label>
              <div className="text-sm text-muted-foreground">
                {config.minDelay} - {config.maxDelay} seconds
              </div>
            </div>
            <Slider
              disabled={isRunning}
              value={[config.minDelay, config.maxDelay]}
              min={5}
              max={120}
              step={1}
              onValueChange={handleDelayRange}
              className="my-4"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default SimulationConfig;
