
import React, { ReactNode } from 'react';
import { SunIcon, MoonIcon, RocketIcon } from 'lucide-react';
import { useTheme } from 'next-themes';
import { Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';

interface LayoutProps {
  children: ReactNode;
}

const Layout = ({ children }: LayoutProps) => {
  const { theme, setTheme } = useTheme();
  const location = useLocation();
  const isDashboard = location.pathname === '/dashboard';
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-white to-gray-100 dark:from-pump-dark dark:to-pump-darker transition-all duration-300">
      <header className="sticky top-0 z-50 backdrop-blur-md bg-white/70 dark:bg-pump/50 border-b border-gray-200 dark:border-pump-light/20">
        <div className="container flex items-center justify-between h-16 px-4 mx-auto">
          <div className="flex items-center space-x-2">
            <Link to="/" className="flex items-center space-x-2">
              <div className="text-solana">
                <RocketIcon size={34} />
              </div>
              <h1 className="text-xl font-medium text-pump-darker dark:text-white">
                Pump.fun <span className="font-normal text-pump-light dark:text-gray-400">Bot</span>
              </h1>
            </Link>
          </div>
          
          <div className="flex items-center space-x-4">
            {!isDashboard && (
              <Link to="/dashboard">
                <Button variant="outline" size="sm" className="mr-2">
                  Launch App
                </Button>
              </Link>
            )}
            <button
              className="p-2 rounded-full bg-gray-100 dark:bg-pump-light text-pump-darker dark:text-white transition-all hover:bg-gray-200 dark:hover:bg-pump-lighter"
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
              aria-label="Toggle theme"
            >
              {theme === 'dark' ? <SunIcon size={18} /> : <MoonIcon size={18} />}
            </button>
          </div>
        </div>
      </header>
      
      <main className="container px-4 py-8 mx-auto">
        {children}
      </main>
      
      <footer className="py-6 mt-8 text-center text-sm text-gray-500 dark:text-gray-400 border-t border-gray-200 dark:border-pump-light/20">
        <div className="container px-4 mx-auto">
          <p>© {new Date().getFullYear()} Trading Pump Bot. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};

export default Layout;
